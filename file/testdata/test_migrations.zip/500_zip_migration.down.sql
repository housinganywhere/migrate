DROP TABLE test_zip;
