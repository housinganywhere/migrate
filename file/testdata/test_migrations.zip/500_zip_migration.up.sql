CREATE TABLE test_zip (id INT);
